import 'package:desktop/src/services/DataService.dart';
import 'package:desktop/src/views/DashboardPage/DashboardPage.dart';
import 'package:desktop/src/views/HomePage/HomePage.dart';
import 'package:desktop/src/views/LoginPage/LoginPage.dart';
import 'package:desktop/src/views/WelcomePage/WelcomePage.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'models/AuthModel.dart';

final goRouterProvider = Provider<GoRouter>((ref) {
  final authService = ref.watch(authServiceProvider);

  return GoRouter(
    routes: [
      GoRoute(
        path: '/home',
        builder: (context, state) => const HomePage(),
      ),
      GoRoute(
        path: '/login',
        builder: (context, state) => const LoginPage(),
      ),
      GoRoute(
        path: '/welcome',
        builder: (context, state) => const WelcomePage(),
      ),
      GoRoute(
        path: '/dashboard/:id',
        builder: (context, state) {
          final id = state.pathParameters['id'] ?? '';
          return DashboardPage(dashboardId: id);
        },
      ),
    ],
    redirect: (context, state) {
      print(state.fullPath);
      print(state.matchedLocation);

      final isAuthenticated = authService.currentUser != null;

      if (state.fullPath == '/login') {
        return '/login';
      }

      return isAuthenticated ? state.matchedLocation : '/welcome';
    },
  );
});

class App extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(goRouterProvider);
    DataService().setRef(ref);
    return MaterialApp.router(
      routeInformationParser: router.routeInformationParser,
      routerDelegate: router.routerDelegate,
      routeInformationProvider: router.routeInformationProvider,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Color.fromRGBO(0, 0, 0, 1),
      ),
      darkTheme: ThemeData(
        brightness: Brightness.light,
        useMaterial3: true,
        colorSchemeSeed: Color.fromRGBO(255, 255, 255, 1),
      ),
    );
  }
}
