import 'dart:math';

import 'package:desktop/src/services/KpiService.dart';
import 'package:desktop/src/views/DashboardPage/widgets/Grid/GridItem.dart';
import 'package:desktop/src/providers/shared_providers.dart';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class DraggableGridItem extends ConsumerStatefulWidget {
  final GridItem item;

  DraggableGridItem({
    Key? key,
    required this.item,
  }) : super(key: key);

  @override
  _DraggableGridItemState createState() => _DraggableGridItemState();
}

class _DraggableGridItemState extends ConsumerState<DraggableGridItem>
    with SingleTickerProviderStateMixin {
  // Initial positions and sizes
  late int initialColumnStart;
  late int initialRowStart;
  late int initialColumnSpan;
  late int initialRowSpan;

  // Final positions and sizes
  late int finalColumnPos;
  late int finalRowPos;
  late int finalColumnSpan;
  late int finalRowSpan;

  // For showing the ghost
  bool showGhost = false;
  Offset ghostPosition = Offset(0, 0);
  Size ghostSize = Size(60, 60);

  // Hover
  AnimationController? _animationController;
  Animation<double>? _opacity;
  Animation<double>? _scale;
  Animation<double>? _rotation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );

    _opacity =
        Tween<double>(begin: 0.0, end: 1.0).animate(_animationController!);
    _scale = Tween<double>(begin: 0.1, end: 1.0).animate(CurvedAnimation(
      parent: _animationController!,
      curve: Curves.easeInOut,
    ));
    _rotation = Tween<double>(begin: -1.0, end: 0.0).animate(CurvedAnimation(
      parent: _animationController!,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _animationController?.dispose();
    super.dispose();
  }

  void _handleHover(bool isHovering) {
    if (isHovering) {
      _animationController?.forward();
    } else {
      _animationController?.reverse();
    }
  }

  void deleteKpi() {
    ref.read(gridItemsProvider.notifier).deleteKpi(widget.item.id.toString());
  }

  // DRAG HANDLERS
  // =============

  void handleDragStart(BuildContext context, DragStartDetails details) {
    setState(() {
      initialColumnStart = widget.item.columnStart;
      initialRowStart = widget.item.rowStart;
      showGhost = true;
      ghostPosition = Offset(initialColumnStart * 50.0, initialRowStart * 50.0);
      ghostSize =
          Size(widget.item.columnSpan * 50.0, widget.item.rowSpan * 50.0);
    });
  }

  void handleDragUpdate(BuildContext context, DragUpdateDetails details) {
    final localPosition = details.localPosition;
    setState(() {
      finalColumnPos = initialColumnStart + (localPosition.dx / 50).floor();
      finalRowPos = initialRowStart + (localPosition.dy / 50).floor();
      ghostPosition = Offset(finalColumnPos * 50.0, finalRowPos * 50.0);
    });
  }

  void handleDragEnd(BuildContext context, DragEndDetails details) {
    ref
        .read(gridItemsProvider.notifier)
        .updateItemPosition('${widget.item.id}', finalColumnPos, finalRowPos);
    setState(() => showGhost = false);
  }

  // RESIZE HANDLERS
  // ===============

  void handleResizeStart(BuildContext context, DragStartDetails details) {
    setState(() {
      initialColumnSpan = widget.item.columnSpan;
      initialRowSpan = widget.item.rowSpan;
      showGhost = true;
      ghostPosition =
          Offset(widget.item.columnStart * 50.0, widget.item.rowStart * 50.0);
      ghostSize = Size(initialColumnSpan * 50.0, initialRowSpan * 50.0);
    });
  }

  void handleResizeUpdate(BuildContext context, DragUpdateDetails details) {
    final localPosition = details.localPosition;
    setState(() {
      finalColumnSpan = initialColumnSpan + (localPosition.dx / 50).floor();
      finalRowSpan = initialRowSpan + (localPosition.dy / 50).floor();
      if (finalColumnSpan > 0 && finalRowSpan > 0) {
        ghostSize = Size(finalColumnSpan * 50.0, finalRowSpan * 50.0);
      }
    });
  }

  void handleResizeEnd(BuildContext context, DragEndDetails details) {
    if (finalColumnSpan > 0 && finalRowSpan > 0) {
      ref
          .read(gridItemsProvider.notifier)
          .updateItemSize('${widget.item.id}', finalColumnSpan, finalRowSpan);
    }
    setState(() => showGhost = false);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GestureDetector(
          onPanStart: (details) => handleDragStart(context, details),
          onPanUpdate: (details) => handleDragUpdate(context, details),
          onPanEnd: (details) => handleDragEnd(context, details),
          child: Container(
            width: widget.item.columnSpan * 50.0,
            height: widget.item.rowSpan * 50.0,
            decoration: BoxDecoration(
                color: const Color.fromARGB(255, 255, 255, 255),
                borderRadius: BorderRadius.all(Radius.circular(10)),
                boxShadow: [
                  BoxShadow(
                    color: Color.fromARGB(255, 216, 216, 216).withOpacity(1),
                    offset: Offset(0, 6),
                    blurRadius: 12,
                    spreadRadius: 0.1,
                  ),
                ]),
            child: InkWell(
              onTap: () {},
              onHover: _handleHover,
              child: Stack(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Center(
                      child: widget.item.child,
                    ),
                  ),
                  Positioned(
                    bottom: 5,
                    right: 5,
                    child: AnimatedBuilder(
                      animation: _animationController!,
                      builder: (context, child) {
                        return Transform.rotate(
                          angle: _rotation!.value, // Rotation animation
                          child: Transform.scale(
                            scale: _scale!.value, // Scale animation
                            child: Opacity(
                              opacity: _opacity!.value, // Opacity animation
                              child: GestureDetector(
                                onPanStart: (details) =>
                                    handleResizeStart(context, details),
                                onPanUpdate: (details) =>
                                    handleResizeUpdate(context, details),
                                onPanEnd: (details) =>
                                    handleResizeEnd(context, details),
                                child: Transform.rotate(
                                  angle: pi / 2,
                                  child: Icon(Icons.arrow_outward,
                                      color: Colors.grey),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  Positioned(
                    top: 10,
                    right: 10,
                    child: AnimatedBuilder(
                      animation: _animationController!,
                      builder: (context, child) {
                        return Transform.rotate(
                          angle: _rotation!.value, // Rotation animation
                          child: Transform.scale(
                            scale: _scale!.value, // Scale animation
                            child: Opacity(
                              opacity: _opacity!.value, // Opacity animation
                              child: GestureDetector(
                                onTap: () => deleteKpi(),
                                child: Icon(Icons.close, color: Colors.grey),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
