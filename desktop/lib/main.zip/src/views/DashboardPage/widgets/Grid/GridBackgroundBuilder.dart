import 'package:desktop/src/views/DashboardPage/widgets/Grid/GridWidget.dart';
import 'package:flutter/material.dart';

class GridBackgroundBuilder extends StatelessWidget {
  final double cellWidth;
  final double cellHeight;
  final Rect viewport;

  const GridBackgroundBuilder({
    Key? key,
    required this.cellWidth,
    required this.cellHeight,
    required this.viewport,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final int firstRow = (viewport.top / cellHeight).floor();
    final int lastRow = (viewport.bottom / cellHeight).ceil();
    final int firstCol = (viewport.left / cellWidth).floor();
    final int lastCol = (viewport.right / cellWidth).ceil();

    final colors = Theme.of(context).colorScheme;

    return Material(
      color: colors.background,
      child: Stack(
        children: [
          for (int row = firstRow; row < lastRow; row++)
            for (int col = firstCol; col < lastCol; col++)
              Positioned(
                left: col * cellWidth,
                top: row * cellHeight,
                child: Container(
                  height: cellHeight,
                  width: cellWidth,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: colors.onBackground.withOpacity(0.1),
                      width: 0.25,
                    ),
                  ),
                ),
              ),
        ],
      ),
    );
  }
}
