class GraphConfig {
  String graphType;
  // Add more fields as per your requirement

  GraphConfig({this.graphType = 'bar'}); // Default to a bar graph, for example
}
