import 'package:desktop/src/models/AuthModel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

class LoginPage extends ConsumerStatefulWidget {
  const LoginPage({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() {
    return LoginPageState();
  }
}

class LoginPageState extends ConsumerState<LoginPage> {
  final _formKey = GlobalKey<FormState>();

  final usernameController = TextEditingController();
  final passwordController = TextEditingController();

  String? _errorMessage;

  @override
  void initState() {
    super.initState();

    // final auth = Provider.of<AuthModel>(context, listen: false);
    // if (auth.isSignedIn) {
    //   context.go('/home');
    // }

    ref.listenManual(authServiceProvider, (previous, next) {
      if (next.currentUser == null) {
        context.go('/home');
      }
    });
  }

  @override
  void dispose() {
    usernameController.dispose();
    passwordController.dispose();
    super.dispose();
  }

// TODO: Add error cheking
  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context)
        .textTheme
        .apply(displayColor: Theme.of(context).colorScheme.onSurface);

    return Scaffold(
      body: Center(
          child: Column(
        children: [
          Form(
              key: _formKey,
              child: Column(
                children: [
                  Container(
                    height: MediaQuery.of(context).size.height * 0.2,
                    padding: const EdgeInsets.fromLTRB(200, 20, 20, 20),
                    child: Row(
                      children: [
                        const Text(
                            style: TextStyle(
                                fontSize: 100, fontWeight: FontWeight.bold),
                            'Welcome to '),
                        Text(
                            style: TextStyle(
                                fontSize: 100,
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context)
                                    .buttonTheme
                                    .colorScheme
                                    ?.primary),
                            'nobi.')
                      ],
                    ),
                  ),
                  Container(
                    height: MediaQuery.of(context).size.height * 0.5,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Column(
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width * 0.3,
                              child: TextFormField(
                                controller: usernameController,
                                decoration: const InputDecoration(
                                  border: OutlineInputBorder(),
                                  labelText: 'User',
                                ),
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please enter some text';
                                  }
                                  return null;
                                },
                              ),
                            ),
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.01,
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width * 0.3,
                              child: TextFormField(
                                controller: passwordController,
                                decoration: const InputDecoration(
                                  border: OutlineInputBorder(),
                                  labelText: 'Password',
                                ),
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please enter some text';
                                  }
                                  return null;
                                },
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.01,
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.3,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              ElevatedButton(
                                onPressed: () async {
                                  final model = ref?.read(authServiceProvider);
                                  try {
                                    await model?.signIn(
                                        email: usernameController.text,
                                        password: passwordController.text);
                                    context.go('/home');
                                  } catch (e) {
                                    setState(() {
                                      _errorMessage = e.toString();
                                    });
                                  }
                                },
                                child: const Text('Sign In'),
                              ),
                              ElevatedButton(
                                onPressed: () async {
                                  final model = ref?.read(authServiceProvider);
                                  try {
                                    await model?.logIn(
                                        email: usernameController.text,
                                        password: passwordController.text);
                                    context.go('/home');
                                  } catch (e) {
                                    setState(() {
                                      _errorMessage = e.toString();
                                    });
                                  }
                                },
                                child: const Text('Log In'),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 50,
                        ),
                        if (_errorMessage != null)
                          Text(
                            _errorMessage!,
                            style: const TextStyle(
                                color:
                                    Colors.red), // To display the error in red.
                          )
                      ],
                    ),
                  )
                ],
              )),
        ],
      )),
    );
  }
}
