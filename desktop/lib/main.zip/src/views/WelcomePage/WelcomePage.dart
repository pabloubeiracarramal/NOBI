import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context)
        .textTheme
        .apply(displayColor: Theme.of(context).colorScheme.onSurface);

    return Material(
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(50),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('nobi.', style: textTheme.titleLarge!),
                ElevatedButton(
                  onPressed: () => context.go('/login'),
                  child: Text('Log In'),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.all(150),
            child: Text(
              'Welcome to NOBI. Your data anywhere you go.',
              style: textTheme.titleLarge,
            ),
          )
        ],
      ),
    );
  }
}
