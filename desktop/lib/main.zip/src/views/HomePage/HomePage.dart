import 'package:desktop/src/views/HomePage/components/CustomAppBar.dart';
import 'package:desktop/src/views/HomePage/components/DashboardCard.dart';
import 'package:desktop/src/models/AuthModel.dart';
import 'package:desktop/src/models/DashboardModel.dart';
import 'package:desktop/src/services/DashboardService.dart';
import 'package:desktop/src/views/HomePage/components/DashboardRow.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'components/EmptyDashboardCard.dart';
import '../../models/ApiModel.dart';

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  late Future<List<Dashboard>> userDashboards;

  @override
  void initState() {
    super.initState();
    userDashboards = DashboardService().fetchDashboardsUser();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: CustomAppBar(),

        // Home Page Body
        body: Padding(
          padding: const EdgeInsets.all(50.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Row of dashboards title
                  const Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text('Your Dashboards'),
                  ),

                  // Row containing feched dashboards
                  FutureBuilder<List<Dashboard>>(
                      future: userDashboards,
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.done) {
                          if (snapshot.hasError) {
                            return Text('Error: ${snapshot.error}');
                          }
                          return DashboardRow(
                              dashboardDetails: snapshot.data ?? []);
                        } else {
                          return const CircularProgressIndicator();
                        }
                      }),
                ],
              ),
            ],
          ),
        ));
  }
}
