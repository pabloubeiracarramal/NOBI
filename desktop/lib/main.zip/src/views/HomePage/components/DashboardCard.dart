import 'package:desktop/src/models/DashboardModel.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class DashboardCard extends StatelessWidget {
  final Dashboard dashboard;

  DashboardCard({required this.dashboard});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => context.go('/dashboard/${dashboard.dashboardId}'),
      child: Container(
        width: 200,
        height: 200,
        child: Card(
          color: Theme.of(context).cardColor,
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [Text(dashboard.title)],
            ),
          ),
        ),
      ),
    );
  }
}
